% NLOPT_AUGLAG_EQ: Augmented Lagrangian method for equality constraints (needs sub-algorithm)
%
% See nlopt_minimize for more information.
function val = NLOPT_AUGLAG_EQ
  val = 37;
