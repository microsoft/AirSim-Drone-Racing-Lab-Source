% NLOPT_LN_NELDERMEAD: Nelder-Mead simplex algorithm (local, no-derivative)
%
% See nlopt_minimize for more information.
function val = NLOPT_LN_NELDERMEAD
  val = 28;
