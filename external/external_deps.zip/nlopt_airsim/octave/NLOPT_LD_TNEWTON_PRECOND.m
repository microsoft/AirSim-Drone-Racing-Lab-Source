% NLOPT_LD_TNEWTON_PRECOND: Preconditioned truncated Newton (local, derivative-based)
%
% See nlopt_minimize for more information.
function val = NLOPT_LD_TNEWTON_PRECOND
  val = 17;
